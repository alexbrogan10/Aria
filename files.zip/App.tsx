import React, { useCallback, useRef } from 'react';
import { ScoreProvider, useStore, useScore, useEditor } from './store';
import { StaffRenderer } from './components/StaffRenderer';
import { useKeyboardShortcuts } from './hooks/useKeyboard';
import { useElectron, isElectron, platform } from './hooks/useElectron';
import { playbackEngine } from './utils/playback';
import { downloadMusicXml, downloadJson } from './utils/export';
import { DURATION_UNICODE, DURATION_LABELS, formatPitch } from './utils/music';
import type { DurationValue, Accidental, NoteElement, Pitch } from './types';

// ─── Constants ────────────────────────────────────────────────────────────────
const DURATIONS: DurationValue[] = ['whole', 'half', 'quarter', 'eighth', '16th', '32nd'];
const LINE_SPACING = 7;
const STAFF_HEIGHT = LINE_SPACING * 4;
const SYSTEM_GAP = 48;
const MEASURE_WIDTH = 180;

// ─── App shell ────────────────────────────────────────────────────────────────
export default function App() {
  return (
    <ScoreProvider>
      <AppInner />
    </ScoreProvider>
  );
}

function AppInner() {
  useKeyboardShortcuts();
  const { save, exportMusicXml } = useElectron();
  const { state, dispatch } = useStore();
  const score = useScore();
  const editor = useEditor();

  // ── Playback ───────────────────────────────────────────────────────────────
  const handlePlayPause = useCallback(async () => {
    await playbackEngine.resume();
    if (editor.isPlaying) {
      playbackEngine.stop();
      dispatch({ type: 'SET_PLAYING', playing: false });
    } else {
      dispatch({ type: 'SET_PLAYING', playing: true });
      playbackEngine.play(score, editor.playheadMeasure, (beat, measure) => {
        if (beat === -1) {
          dispatch({ type: 'SET_PLAYING', playing: false });
          dispatch({ type: 'SET_PLAYHEAD', measure: 0, beat: 0 });
        } else {
          dispatch({ type: 'SET_PLAYHEAD', measure, beat });
        }
      });
    }
  }, [editor.isPlaying, editor.playheadMeasure, score, dispatch]);

  // ── Selection ──────────────────────────────────────────────────────────────
  const handleElementClick = useCallback((id: string, e: React.MouseEvent) => {
    if (e.shiftKey) {
      const ids = editor.selection.elementIds.includes(id)
        ? editor.selection.elementIds.filter(i => i !== id)
        : [...editor.selection.elementIds, id];
      dispatch({ type: 'SELECT_ELEMENTS', ids });
    } else {
      dispatch({ type: 'SELECT_ELEMENTS', ids: [id] });
    }
  }, [editor.selection.elementIds, dispatch]);

  // ── Note insertion on staff click ──────────────────────────────────────────
  const handleStaffClick = useCallback((partId: string, measureId: string, e: React.MouseEvent) => {
    if (editor.activeTool !== 'note-input') return;

    // Map click Y position to a pitch based on staff position
    const svg = (e.currentTarget as SVGElement).ownerSVGElement;
    if (!svg) return;
    const rect = svg.getBoundingClientRect();
    const relY = e.clientY - rect.top;

    // Simple pitch mapping from Y (approximate)
    const steps: Array<{ step: string; octave: number }> = [
      { step: 'C', octave: 6 }, { step: 'B', octave: 5 }, { step: 'A', octave: 5 },
      { step: 'G', octave: 5 }, { step: 'F', octave: 5 }, { step: 'E', octave: 5 },
      { step: 'D', octave: 5 }, { step: 'C', octave: 5 }, { step: 'B', octave: 4 },
      { step: 'A', octave: 4 }, { step: 'G', octave: 4 }, { step: 'F', octave: 4 },
      { step: 'E', octave: 4 }, { step: 'D', octave: 4 }, { step: 'C', octave: 4 },
    ];
    const idx = Math.max(0, Math.min(steps.length - 1, Math.floor(relY / (LINE_SPACING / 2))));
    const { step, octave } = steps[idx];

    const pitch: Pitch = {
      step: step as Pitch['step'],
      octave,
      accidental: editor.activeAccidental,
      alter: editor.activeAccidental === 'sharp' ? 1 : editor.activeAccidental === 'flat' ? -1 : 0,
    };

    dispatch({ type: 'INSERT_NOTE', partId, measureId, pitch });
  }, [editor.activeTool, editor.activeAccidental, dispatch]);

  // ── Selected element info for properties panel ─────────────────────────────
  const selectedId = editor.selection.elementIds[0];
  const selectedElement = selectedId ? score.parts.flatMap(p =>
    p.measures.flatMap(m => m.elements)
  ).find(el => el.id === selectedId) : null;

  return (
    <div style={styles.app}>
      {/* ── Menu bar ── */}
      <div style={styles.menubar}>
        <span style={styles.menuLogo}>♩ Aria</span>
        {['File', 'Edit', 'Score', 'Notation', 'Playback', 'View'].map(item => (
          <span key={item} style={styles.menuItem}>{item}</span>
        ))}
        <span style={{ flex: 1 }} />
        <span style={styles.menuStatus}>
          {score.metadata.title} · {isElectron ? `${platform === 'darwin' ? 'Mac' : 'Windows'} App` : 'Web'} · Autosaved
        </span>
      </div>

      {/* ── Toolbar ── */}
      <div style={styles.toolbar}>
        {/* Tool mode */}
        <div style={styles.toolGroup}>
          {(['select', 'note-input', 'erase'] as const).map(tool => (
            <button key={tool} title={tool}
              style={{ ...styles.toolBtn, ...(editor.activeTool === tool ? styles.toolBtnActive : {}) }}
              onClick={() => dispatch({ type: 'SET_TOOL', tool })}>
              {tool === 'select' ? '▷' : tool === 'note-input' ? '♩' : '✕'}
            </button>
          ))}
        </div>

        {/* Duration */}
        <div style={styles.toolGroup}>
          {DURATIONS.map((d, i) => (
            <button key={d} title={DURATION_LABELS[d]}
              style={{ ...styles.toolBtn, ...(editor.noteInputDuration === d ? styles.toolBtnActive : {}) }}
              onClick={() => dispatch({ type: 'SET_DURATION', duration: d })}>
              {i + 1}
            </button>
          ))}
          <button title="Dot"
            style={{ ...styles.toolBtn, ...(editor.noteInputDots > 0 ? styles.toolBtnActive : {}), fontWeight: 700 }}
            onClick={() => dispatch({ type: 'SET_DOTS', dots: editor.noteInputDots > 0 ? 0 : 1 })}>
            .
          </button>
        </div>

        {/* Accidentals */}
        <div style={styles.toolGroup}>
          {([['flat', '♭'], ['natural', '♮'], ['sharp', '♯']] as [Accidental, string][]).map(([acc, sym]) => (
            <button key={acc} title={acc ?? 'natural'}
              style={{ ...styles.toolBtn, ...(editor.activeAccidental === acc ? styles.toolBtnActive : {}) }}
              onClick={() => dispatch({ type: 'SET_ACCIDENTAL', accidental: editor.activeAccidental === acc ? null : acc })}>
              {sym}
            </button>
          ))}
        </div>

        {/* Undo/Redo */}
        <div style={styles.toolGroup}>
          <button style={styles.toolBtn} title="Undo (Ctrl+Z)" onClick={() => dispatch({ type: 'UNDO' })} disabled={state.history.length === 0}>↩</button>
          <button style={styles.toolBtn} title="Redo (Ctrl+Y)" onClick={() => dispatch({ type: 'REDO' })} disabled={state.future.length === 0}>↪</button>
        </div>

        {/* Zoom */}
        <div style={styles.toolGroup}>
          <button style={styles.toolBtn} onClick={() => dispatch({ type: 'SET_ZOOM', zoom: editor.zoom - 0.1 })}>−</button>
          <span style={{ fontSize: 11, color: '#888', padding: '0 4px', minWidth: 36, textAlign: 'center' }}>{Math.round(editor.zoom * 100)}%</span>
          <button style={styles.toolBtn} onClick={() => dispatch({ type: 'SET_ZOOM', zoom: editor.zoom + 0.1 })}>+</button>
        </div>

        {/* Add measure */}
        <div style={styles.toolGroup}>
          <button style={styles.toolBtn} title="Add Measure" onClick={() => dispatch({ type: 'ADD_MEASURE' })}>+𝄚</button>
        </div>

        {/* Export */}
        <div style={styles.toolGroup}>
          <button style={{ ...styles.toolBtn, fontSize: 10 }} onClick={() => downloadMusicXml(score)}>MusicXML</button>
          <button style={{ ...styles.toolBtn, fontSize: 10 }} onClick={() => downloadJson(score)}>JSON</button>
        </div>
      </div>

      {/* ── Main area ── */}
      <div style={styles.main}>

        {/* ── Left palette ── */}
        <div style={styles.leftPanel}>
          <PaletteSection title="Notes & Rests">
            {DURATIONS.map((d, i) => (
              <div key={d} style={{ ...styles.palItem, ...(editor.noteInputDuration === d ? styles.palItemActive : {}) }}
                onClick={() => dispatch({ type: 'SET_DURATION', duration: d })}
                title={DURATION_LABELS[d]}>
                {i + 1}
              </div>
            ))}
          </PaletteSection>
          <PaletteSection title="Dynamics">
            {(['pp', 'p', 'mp', 'mf', 'f', 'ff'] as const).map(d => (
              <div key={d} style={{ ...styles.palItem, fontStyle: 'italic', fontSize: 11 }}>{d}</div>
            ))}
          </PaletteSection>
          <PaletteSection title="Articulations">
            {[['staccato', '•'], ['accent', '>'], ['tenuto', '—'], ['marcato', '^'], ['fermata', '𝄐'], ['trill', 'tr']].map(([a, sym]) => (
              <div key={a} style={styles.palItem}
                title={a}
                onClick={() => {
                  if (editor.selection.elementIds.length > 0)
                    dispatch({ type: 'SET_ARTICULATION', elementIds: editor.selection.elementIds, articulation: a as any });
                }}>
                {sym}
              </div>
            ))}
          </PaletteSection>
          <PaletteSection title="Lines">
            {[['slur', '⌢'], ['cresc', '<'], ['dim', '>'], ['8va', '8va']].map(([n, s]) => (
              <div key={n} style={styles.palItem} title={n}>{s}</div>
            ))}
          </PaletteSection>
        </div>

        {/* ── Score canvas ── */}
        <div style={{ ...styles.scoreArea }} onClick={() => dispatch({ type: 'CLEAR_SELECTION' })}>
          <div style={{ ...styles.scorePage, transform: `scale(${editor.zoom})`, transformOrigin: 'top center' }}>
            {/* Title block */}
            <div style={{ textAlign: 'center', marginBottom: 24 }}>
              <div style={{ fontSize: 20, fontWeight: 500, letterSpacing: -0.3 }}>{score.metadata.title}</div>
              {score.metadata.subtitle && <div style={{ fontSize: 13, color: '#888', marginTop: 2 }}>{score.metadata.subtitle}</div>}
              {score.metadata.composer && <div style={{ fontSize: 12, color: '#888', marginTop: 4 }}>{score.metadata.composer}</div>}
            </div>

            {/* Systems */}
            {score.parts.map(part => (
              <div key={part.id} style={{ marginBottom: 32 }}>
                <div style={{ fontSize: 10, color: '#888', marginBottom: 4, fontStyle: 'italic' }}>
                  {part.instrument.name}
                </div>
                <svg
                  width={part.measures.length * MEASURE_WIDTH + 16}
                  height={STAFF_HEIGHT + LINE_SPACING * 4}
                  style={{ display: 'block', overflow: 'visible' }}>
                  {part.measures.map((measure, mi) => (
                    <StaffRenderer
                      key={measure.id}
                      part={part}
                      measure={measure}
                      measureIndex={mi}
                      x={mi * MEASURE_WIDTH}
                      y={LINE_SPACING * 2}
                      width={MEASURE_WIDTH}
                      staffHeight={STAFF_HEIGHT}
                      lineSpacing={LINE_SPACING}
                      isSelected={id => editor.selection.elementIds.includes(id)}
                      onElementClick={handleElementClick}
                      onStaffClick={handleStaffClick}
                    />
                  ))}
                  {/* Final double barline */}
                  <line
                    x1={part.measures.length * MEASURE_WIDTH - 2} y1={LINE_SPACING * 2}
                    x2={part.measures.length * MEASURE_WIDTH - 2} y2={LINE_SPACING * 2 + STAFF_HEIGHT}
                    stroke="#1a1a18" strokeWidth={1} />
                  <line
                    x1={part.measures.length * MEASURE_WIDTH} y1={LINE_SPACING * 2}
                    x2={part.measures.length * MEASURE_WIDTH} y2={LINE_SPACING * 2 + STAFF_HEIGHT}
                    stroke="#1a1a18" strokeWidth={3} />
                </svg>
                {/* Measure numbers */}
                <div style={{ display: 'flex' }}>
                  {part.measures.map((m, mi) => (
                    <div key={m.id} style={{ width: MEASURE_WIDTH, fontSize: 9, color: '#aaa', paddingLeft: 4 }}>{m.number}</div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ── Properties panel ── */}
        <div style={styles.rightPanel}>
          <div style={styles.propsHeader}>
            {selectedElement ? `Properties — ${selectedElement.type}` : 'Properties'}
          </div>

          {selectedElement?.type === 'note' && (() => {
            const note = selectedElement as NoteElement;
            return (
              <>
                <PropGroup label="Pitch">
                  <PropRow name="Note" value={<Badge>{formatPitch(note.pitch)}</Badge>} />
                  <PropRow name="MIDI" value={String(note.pitch.octave * 12 + 60)} />
                </PropGroup>
                <PropGroup label="Duration">
                  <PropRow name="Value" value={<Badge>{DURATION_LABELS[note.duration.value]}</Badge>} />
                  <PropRow name="Dots" value={note.duration.dots > 0 ? '●'.repeat(note.duration.dots) : '—'} />
                </PropGroup>
                <PropGroup label="Voice & Stem">
                  <PropRow name="Voice" value={String(note.voice)} />
                  <PropRow name="Stem" value={note.stem ?? 'auto'} />
                </PropGroup>
                {note.articulations.length > 0 && (
                  <PropGroup label="Articulations">
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                      {note.articulations.map(a => <Badge key={a}>{a}</Badge>)}
                    </div>
                  </PropGroup>
                )}
                <PropGroup label="Actions">
                  <button style={styles.miniBtn} onClick={() => dispatch({ type: 'DELETE_SELECTED' })}>🗑 Delete</button>
                </PropGroup>
              </>
            );
          })()}

          {!selectedElement && (
            <div style={{ padding: '20px 12px', fontSize: 11, color: '#aaa', lineHeight: 1.6 }}>
              Click a note or rest to see its properties here.
              <br /><br />
              <b style={{ color: '#888' }}>Shortcuts</b><br />
              N — Note input<br />
              1–6 — Duration<br />
              . — Dot<br />
              Space — Play/pause<br />
              Del — Delete<br />
              Ctrl+Z — Undo
            </div>
          )}

          {/* Score info at bottom */}
          <div style={{ marginTop: 'auto', padding: '10px 12px', borderTop: '0.5px solid #e5e5e5' }}>
            <div style={{ fontSize: 10, color: '#aaa', marginBottom: 6, textTransform: 'uppercase', letterSpacing: 0.4 }}>Score</div>
            <div style={{ fontSize: 11, color: '#555', marginBottom: 3 }}>{score.parts.length} parts</div>
            <div style={{ fontSize: 11, color: '#555', marginBottom: 3 }}>{score.measureCount} measures</div>
            <div style={{ fontSize: 11, color: '#555' }}>♩ = {score.globalTempo.bpm} {score.globalTempo.text}</div>
          </div>
        </div>
      </div>

      {/* ── Playback bar ── */}
      <div style={styles.playbar}>
        <button style={styles.playBtn} onClick={handlePlayPause}>
          {editor.isPlaying ? '⏸' : '▶'}
        </button>
        <span style={{ fontSize: 11, color: '#888', minWidth: 40 }}>
          M{editor.playheadMeasure + 1}
        </span>
        <div style={styles.playTrack}>
          <div style={{ ...styles.playFill, width: `${(editor.playheadMeasure / Math.max(score.measureCount - 1, 1)) * 100}%` }} />
        </div>
        <div style={{ fontSize: 11, color: '#666' }}>
          ♩ = <b>{score.globalTempo.bpm}</b>
        </div>
        <span style={{ fontSize: 11, color: '#aaa', fontStyle: 'italic' }}>{score.globalTempo.text}</span>
      </div>

      {/* ── Status bar ── */}
      <div style={styles.statusbar}>
        <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#5a9c2c', display: 'inline-block', marginRight: 6 }} />
        <span>Ready</span>
        <span style={{ margin: '0 16px', color: '#ccc' }}>|</span>
        {selectedElement?.type === 'note'
          ? <span>Selected: {formatPitch((selectedElement as NoteElement).pitch)} · {DURATION_LABELS[(selectedElement as NoteElement).duration.value]}</span>
          : <span>Tool: {editor.activeTool}</span>}
        <span style={{ flex: 1 }} />
        <span>{score.parts.length} parts · {score.measureCount} measures</span>
      </div>
    </div>
  );
}

// ─── Small reusable components ────────────────────────────────────────────────
function PaletteSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div style={{ borderBottom: '0.5px solid #e8e8e5' }}>
      <div style={{ padding: '8px 12px 4px', fontSize: 10, fontWeight: 500, color: '#aaa', textTransform: 'uppercase', letterSpacing: 0.6 }}>{title}</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 2, padding: '0 8px 8px' }}>{children}</div>
    </div>
  );
}

function PropGroup({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div style={{ padding: '8px 12px', borderBottom: '0.5px solid #f0f0ee' }}>
      <div style={{ fontSize: 10, fontWeight: 500, color: '#aaa', textTransform: 'uppercase', letterSpacing: 0.4, marginBottom: 6 }}>{label}</div>
      {children}
    </div>
  );
}

function PropRow({ name, value }: { name: string; value: React.ReactNode }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 5 }}>
      <span style={{ fontSize: 12, color: '#666' }}>{name}</span>
      <span style={{ fontSize: 12, fontWeight: 500 }}>{value}</span>
    </div>
  );
}

function Badge({ children }: { children: React.ReactNode }) {
  return (
    <span style={{ fontSize: 10, padding: '2px 7px', borderRadius: 10, background: '#E6F1FB', color: '#185FA5', fontWeight: 500 }}>
      {children}
    </span>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────
const styles: Record<string, React.CSSProperties> = {
  app: { display: 'flex', flexDirection: 'column', height: '100vh', background: '#fafaf8', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif' },
  menubar: { display: 'flex', alignItems: 'center', gap: 0, padding: '0 12px', height: 32, background: '#f0efeb', borderBottom: '0.5px solid #ddd', fontSize: 12, color: '#555', flexShrink: 0 },
  menuLogo: { fontWeight: 600, fontSize: 13, color: '#1a1a18', marginRight: 16, letterSpacing: -0.3 },
  menuItem: { padding: '4px 10px', borderRadius: 4, cursor: 'pointer' },
  menuStatus: { fontSize: 11, color: '#aaa' },
  toolbar: { display: 'flex', alignItems: 'center', gap: 2, padding: '4px 10px', height: 44, background: '#fff', borderBottom: '0.5px solid #e8e8e5', flexShrink: 0 },
  toolGroup: { display: 'flex', alignItems: 'center', gap: 1, paddingRight: 8, marginRight: 4, borderRight: '0.5px solid #e8e8e5' },
  toolBtn: { width: 28, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: 5, cursor: 'pointer', fontSize: 13, color: '#555', border: '0.5px solid transparent', background: 'transparent' },
  toolBtnActive: { background: '#E6F1FB', color: '#185FA5', borderColor: '#B5D4F4' },
  main: { display: 'flex', flex: 1, overflow: 'hidden' },
  leftPanel: { width: 176, borderRight: '0.5px solid #e8e8e5', background: '#f8f8f6', flexShrink: 0, overflowY: 'auto' },
  palItem: { aspectRatio: '1', display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: 4, cursor: 'pointer', fontSize: 14, border: '0.5px solid transparent', background: '#fff', transition: 'all 0.1s' },
  palItemActive: { background: '#E6F1FB', borderColor: '#B5D4F4', color: '#185FA5' },
  scoreArea: { flex: 1, overflowY: 'auto', background: '#eeede9', padding: 24 },
  scorePage: { margin: '0 auto', maxWidth: 760, background: 'white', padding: '48px 56px', borderRadius: 2, border: '0.5px solid #d0cec6', boxShadow: '0 1px 6px rgba(0,0,0,0.07)' },
  rightPanel: { width: 196, borderLeft: '0.5px solid #e8e8e5', background: '#f8f8f6', display: 'flex', flexDirection: 'column', flexShrink: 0, overflowY: 'auto' },
  propsHeader: { padding: '10px 12px 8px', fontSize: 11, fontWeight: 500, color: '#666', borderBottom: '0.5px solid #e8e8e5' },
  playbar: { display: 'flex', alignItems: 'center', gap: 10, padding: '0 14px', height: 38, background: '#fff', borderTop: '0.5px solid #e8e8e5', flexShrink: 0 },
  playBtn: { width: 28, height: 28, borderRadius: '50%', background: '#185FA5', border: 'none', color: 'white', fontSize: 12, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' },
  playTrack: { flex: 1, height: 3, background: '#e8e8e5', borderRadius: 2, position: 'relative' },
  playFill: { height: '100%', background: '#185FA5', borderRadius: 2, transition: 'width 0.1s' },
  statusbar: { display: 'flex', alignItems: 'center', padding: '0 14px', height: 24, background: '#f0efeb', borderTop: '0.5px solid #e0dfdb', fontSize: 11, color: '#888', flexShrink: 0 },
  miniBtn: { fontSize: 11, padding: '4px 10px', borderRadius: 4, border: '0.5px solid #ddd', background: '#fff', cursor: 'pointer', color: '#555' },
};
